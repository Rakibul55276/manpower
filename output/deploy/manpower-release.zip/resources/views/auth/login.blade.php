<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Sign in · Manpower</title>
    <link rel="stylesheet" href="{{ asset('css/manpower.css') }}">
</head>
<body>
<div class="login-page">
    <div class="login-art">
        <div class="brand"><span class="brand-mark">m</span><span>manpower<small>WORKFORCE MANAGEMENT</small></span></div>
        <div class="login-copy">
            <div class="eyebrow" style="color:#b9edc9">People. Hours. Progress.</div>
            <h1>Good work starts<br>with good people.</h1>
            <p>One place to manage your workforce, track every hour, and keep payroll on course.</p>
            <div class="login-tags"><span>Rental manpower</span><span>Own employees</span><span>Company access</span></div>
        </div>
        <small style="color:#91b1b0;z-index:1">Built for the people behind the work.</small>
    </div>
    <div class="login-form-wrap">
        <div class="login-form">
            <div class="eyebrow">Welcome back</div>
            <h1>Sign in to your workspace</h1>
            <p class="description">Use your Super Admin or Manager account.</p>
            @if($errors->any())<div class="notice error" style="margin-top:22px" role="alert">{{ $errors->first() }}</div>@endif
            <form method="POST" action="{{ route('login.submit') }}">
                @csrf
                <div class="field">
                    <label for="username">Username</label>
                    <input id="username" name="username" type="text" value="{{ old('username') }}" required autofocus autocomplete="username" placeholder="admin or manager">
                </div>
                <div class="field">
                    <label for="password">Password</label>
                    <input id="password" name="password" type="password" required autocomplete="current-password" placeholder="Enter your password">
                </div>
                <button class="btn" type="submit">Sign in →</button>
            </form>
            <p class="login-bottom">Need access or a password reset?<br>Contact your Super Admin.</p>
        </div>
    </div>
</div>
</body>
</html>
